// lib/models/watchlist_model.dart
class WatchlistModel {
  final String symbol;
  final String name;

  WatchlistModel({required this.symbol, required this.name});
}